Make sure you have a C compiler, make, wget, and zip installed.
Type:

    make

and it should yank over all the data files, some documentation,
compile the code, execute it, and leave behind some .mod files.


